#!/usr/bin/perl -w
# This file was preprocessed, do not edit!


package Debconf::Element;
use strict;
use base qw(Debconf::Base);


sub visible {
	my $this=shift;
	
	return 1;
}


sub show {}


1
